--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE liat_thequeen;
--
-- Name: liat_thequeen; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE liat_thequeen WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE liat_thequeen OWNER TO postgres;

\connect liat_thequeen

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: liat; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA liat;


ALTER SCHEMA liat OWNER TO postgres;

--
-- Name: SCHEMA liat; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA liat IS 'standard public schema';


--
-- Name: adminpack; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS adminpack WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION adminpack; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION adminpack IS 'administrative functions for PostgreSQL';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: t_depart; Type: TABLE; Schema: liat; Owner: postgres
--

CREATE TABLE liat.t_depart (
    deptno text NOT NULL,
    deptname text NOT NULL,
    mgrno text,
    admrdept text
);


ALTER TABLE liat.t_depart OWNER TO postgres;

--
-- Name: t_empl; Type: TABLE; Schema: liat; Owner: postgres
--

CREATE TABLE liat.t_empl (
    empno text NOT NULL,
    firstname text NOT NULL,
    lastname text NOT NULL,
    deptno text,
    hiredate date,
    job text,
    edlevel integer,
    sex text,
    birthdate date,
    salary integer,
    bonus integer,
    comm integer
);


ALTER TABLE liat.t_empl OWNER TO postgres;

--
-- Name: t_proj; Type: TABLE; Schema: liat; Owner: postgres
--

CREATE TABLE liat.t_proj (
    projno text NOT NULL,
    projname text NOT NULL,
    deptno text,
    respemp text NOT NULL,
    prstaff double precision,
    prstdate date,
    prendate date,
    majproj text
);


ALTER TABLE liat.t_proj OWNER TO postgres;

--
-- Data for Name: t_depart; Type: TABLE DATA; Schema: liat; Owner: postgres
--

COPY liat.t_depart (deptno, deptname, mgrno, admrdept) FROM stdin;
\.
COPY liat.t_depart (deptno, deptname, mgrno, admrdept) FROM '$$PATH$$/3323.dat';

--
-- Data for Name: t_empl; Type: TABLE DATA; Schema: liat; Owner: postgres
--

COPY liat.t_empl (empno, firstname, lastname, deptno, hiredate, job, edlevel, sex, birthdate, salary, bonus, comm) FROM stdin;
\.
COPY liat.t_empl (empno, firstname, lastname, deptno, hiredate, job, edlevel, sex, birthdate, salary, bonus, comm) FROM '$$PATH$$/3324.dat';

--
-- Data for Name: t_proj; Type: TABLE DATA; Schema: liat; Owner: postgres
--

COPY liat.t_proj (projno, projname, deptno, respemp, prstaff, prstdate, prendate, majproj) FROM stdin;
\.
COPY liat.t_proj (projno, projname, deptno, respemp, prstaff, prstdate, prendate, majproj) FROM '$$PATH$$/3325.dat';

--
-- Name: t_depart t_depart_pkey; Type: CONSTRAINT; Schema: liat; Owner: postgres
--

ALTER TABLE ONLY liat.t_depart
    ADD CONSTRAINT t_depart_pkey PRIMARY KEY (deptno);


--
-- Name: t_empl t_empl_pkey; Type: CONSTRAINT; Schema: liat; Owner: postgres
--

ALTER TABLE ONLY liat.t_empl
    ADD CONSTRAINT t_empl_pkey PRIMARY KEY (empno);


--
-- Name: t_proj t_proj_pkey; Type: CONSTRAINT; Schema: liat; Owner: postgres
--

ALTER TABLE ONLY liat.t_proj
    ADD CONSTRAINT t_proj_pkey PRIMARY KEY (projno);


--
-- Name: fki_deptno_emp_fk; Type: INDEX; Schema: liat; Owner: postgres
--

CREATE INDEX fki_deptno_emp_fk ON liat.t_empl USING btree (deptno);


--
-- Name: fki_deptno_fk; Type: INDEX; Schema: liat; Owner: postgres
--

CREATE INDEX fki_deptno_fk ON liat.t_proj USING btree (deptno);


--
-- Name: t_empl deptno_emp_fk; Type: FK CONSTRAINT; Schema: liat; Owner: postgres
--

ALTER TABLE ONLY liat.t_empl
    ADD CONSTRAINT deptno_emp_fk FOREIGN KEY (deptno) REFERENCES liat.t_depart(deptno);


--
-- Name: t_empl deptno_fk; Type: FK CONSTRAINT; Schema: liat; Owner: postgres
--

ALTER TABLE ONLY liat.t_empl
    ADD CONSTRAINT deptno_fk FOREIGN KEY (deptno) REFERENCES liat.t_depart(deptno) NOT VALID;


--
-- Name: t_proj deptno_proj_fk; Type: FK CONSTRAINT; Schema: liat; Owner: postgres
--

ALTER TABLE ONLY liat.t_proj
    ADD CONSTRAINT deptno_proj_fk FOREIGN KEY (deptno) REFERENCES liat.t_depart(deptno);


--
-- PostgreSQL database dump complete
--

